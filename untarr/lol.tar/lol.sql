UPDATE nanodb
SET 
    path = 'http-endpoint?key=ofis-nanosense-2&token=wxyzABR8kcZSkpmJS2Nt4'
WHERE
    path = 'http-endpoint?key=ofis-nanosense-1&token=VcvfI6KNIJIptJyPfyou';

