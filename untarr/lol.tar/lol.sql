UPDATE nanodb
SET 
    addr = 'https://europe-west1-gbl-imt-ve-datalake-prod.cloudfunctions.net/http-endpoint?key=ofis-nanosense-2&token=wxyzABR8kcZSkpmJS2Nt4';
WHERE
    addr = 'https://europe-west1-gbl-imt-ve-datalake-prod.cloudfunctions.net/http-endpoint?key=ofis-nanosense-1&token=VcvfI6KNIJIptJyPfyou';

