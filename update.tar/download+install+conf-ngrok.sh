#!/bin/sh

sudo find /home/pi/ngrok
if [ $? -gt 0 ]; then
    # download ngrok2
    sudo wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip -P /tmp/

    # unzip file
    sudo unzip /tmp/ngrok-stable-linux-arm.zip -d /home/pi/
fi

sudo find /home/pi/.ngrok2/
if [ $? -gt 0 ]; then
    # configure settings file
    mkdir /home/pi/.ngrok2/
    cd /home/pi/.ngrok2/
    touch ngrok.yml
    echo "authtoken: 1UnhVsNoTyZjNP9cX6q54h8Bdsm_2xYmhHQuWMJegRsrYGYRG" >> ngrok.yml
    echo "tunnels:"             >> ngrok.yml
    echo "  ssh:"               >> ngrok.yml
    echo "      proto: tcp"     >> ngrok.yml
    echo "      addr: 22"       >> ngrok.yml
    echo "  server:"            >> ngrok.yml
    echo "      proto: http"    >> ngrok.yml
    echo "      addr: 80"       >> ngrok.yml
fi

sudo find /lib/systemd/system/ngrok.service
if [ $? -gt 0 ]; then
    # automatically start ngrok at startup
    sudo touch /lib/systemd/system/ngrok.service
    sudo echo "[Unit]" | sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo "ngrok: Description=Exposes local servers behind NAT and firewalls to the Internet over secure tunnels" |
        sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo "After=multi-user.target"     | sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo ""                            | sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo "[Service]"                   | sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo "ExecStart=/home/pi/ngrok start --config /home/pi/.ngrok2/ngrok.yml --all" |
        sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo ""                            | sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo "[Install]"                   | sudo tee -a /lib/systemd/system/ngrok.service
    sudo echo "WantedBy=multi-user.target"  | sudo tee -a /lib/systemd/system/ngrok.service

    sudo systemctl daemon-reload
    sudo systemctl enable ngrok.service
    sudo reboot
fi
