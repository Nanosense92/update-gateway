#!/bin/sh

# add the line in /boot/config.txt to enable the usb boot mode
sudo cat /boot/config.txt | grep "program_usb_boot_mode"
if [ $? -gt 0 ]
then
    echo "program_usb_boot_mode=1" | sudo tee -a /boot/config.txt
fi

# raise the swap size to 1024M because 100M is not enough
sudo sed -ri 's/CONF_SWAPSIZE=[[:digit:]]*/CONF_SWAPSIZE=1024/' /etc/dphys-swapfile

# enable swap if memory available in RAM is < 10%
sudo cat /etc/sysctl.conf | grep "vm.swappiness"
if [ $? -gt 0 ]
then
    echo "" | sudo tee -a /etc/sysctl.conf
    echo "###################################################################" | sudo tee -a /etc/sysctl.conf
    echo "#SWAP handling" | sudo tee -a /etc/sysctl.conf
    echo "vm.swappiness = 10" | sudo tee -a /etc/sysctl.conf
fi

# enable cron log file + separate critic messages in multiple log files according to their priority
sudo sed -ri 's/\#(cron\.\*[\s]*\/var\/log\/cron\.log)/\1/' /etc/rsyslog.conf
sudo cat /etc/rsyslog.conf | grep "# save critic messages in different files"
if [ $? -gt 0 ]
then
    echo "" | sudo tee -a /etc/rsyslog.conf
    echo "# save critic messages in different files" | sudo tee -a /etc/rsyslog.conf
    echo "*.emerg   /var/log/emerg" | sudo tee -a /etc/rsyslog.conf
    echo "*.alert   /var/log/alert" | sudo tee -a /etc/rsyslog.conf
    echo "*.crit    /var/log/crit" | sudo tee -a /etc/rsyslog.conf
    echo "*.err     /var/log/err" | sudo tee -a /etc/rsyslog.conf
    echo "# save boot messages in boot.log" | sudo tee -a /etc/rsyslog.conf
    echo "local7.*  /var/log/boot.log" | sudo tee -a /etc/rsyslog.conf
fi

# use tmpfs for /tmp and /var/tmp to mount them in RAM instead of the SD card (to improve its life span)
sudo sed -ri '/tmpfs[\s]*\/tmp\/jeedom[\s]*tmpfs[\s]*[[:alnum:]|,|=]*[\s]*[[:digit:]]*[\s]*[[:digit:]]*/d' /etc/fstab
sudo cat /etc/fstab | grep -P "tmpfs[\s]*\/tmp[\s]*tmpfs.*"
if [ $? -gt 0 ]
then
    echo "tmpfs             /tmp        tmpfs   defaults,noatime,nosuid,size=128M 0 0" | sudo tee -a /etc/fstab
    echo "tmpfs             /var/tmp    tmpfs   defaults,noatime,nosuid,size=100M 0 0" | sudo tee -a /etc/fstab
fi

# install log2ram + configure it
which log2ram
if [ $? -gt 0 ]
then
    cd /tmp
    curl -Lo log2ram.tar.gz https://github.com/azlux/log2ram/archive/master.tar.gz
    tar -xf log2ram.tar.gz
    cd log2ram-master
    chmod +x install.sh && sudo ./install.sh
    cd ..
    rm -rf log2ram-master/
    sudo sed -ri 's/^(SIZE=)[[:digit:]]*[k|K|m|M|g|G]$/\150M/' /etc/log2ram.conf
    sudo sed -ri 's/(USE_RSYNC=)(true|false)/\1true/' /etc/log2ram.conf
fi
