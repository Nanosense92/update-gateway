<?php

exec("echo '0.0' >  nano-version.txt");

include '/var/www/html/nanosense/update.php';

header("Location:main.php");
?>
