<?php
$id = '';
if (isset($_GET['date_offset'])){
    $id = $_GET['date_offset'];
}
if ($id != ''){
    $strJsonFileContents = file_get_contents('/home/pi/Nano-Setting.json');
    $array = json_decode($strJsonFileContents, true);
    foreach($array AS $key => $value){
        if($key == 'timezone'){
            $array[$key] = $id;
        }
    }
    $newjson = json_encode($array,JSON_PRETTY_PRINT);
    file_put_contents('/home/pi/Nano-Setting.json', $newjson);

    header('Location:main.php');
    exit;
}
?>
