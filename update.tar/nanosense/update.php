<?php
$git = array();
$script = array();
$ret = 0;

exec ('sudo git clone https://github.com/Nanosense92/update-gateway.git', $git, $ret);
if ($ret != 0) {
	exec('echo "git clone error" > update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	exit;
}
else {
	exec('echo "repository cloned" > update_log.log');
}

exec ('diff <(shasum update-gateway/update.tar) <(cat update-gateway/shasum.txt)', $script, $ret);
if ($ret != 0) {
	exec('echo "corupted data in update" >> update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	header("Location:main.php");
	exit;
}
else {
	exec('echo "update data validation" >> update_log.log');
}

exec ('tar -xzvf update-gateway/update.tar -C update-gateway', $script, $ret);
if ($ret != 0) {
	exec('echo "decompression failed" >> update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	header("Location:main.php");
	exit;
}
else {
	exec('echo "decompressing update-file" >> update_log.log');
}

exec ('sudo sh update-gateway/update-script.sh', $script, $ret);
if ($ret != 0) {
	exec('echo "update failed" >> update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	header("Location:main.php");
	exit;
}
else {
	exec('echo "update successfully installed" >> update_log.log');
}

echo exec ("sudo rm -rf update-gateway");
header("Location:main.php");

exit;

?>
