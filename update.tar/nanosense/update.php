<?php
$git = array();
$script = array();
$ret = 0;

exec ('sudo git clone https://github.com/Nanosense92/update-gateway.git', $git, $ret);
if ($ret != 0) {
	exec('echo "git clone error" >> /home/pi/update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	exit;
}
else {
	exec('echo "repository cloned" > /home/pi/update_log.log');
}
echo "ok";

exec ("bash -c 'diff <(shasum update-gateway/update.tar) <(cat update-gateway/shasum.txt)'", $script, $ret);
if ($ret != 0) {
	exec('echo "corupted data in update" >> /home/pi/update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	header("Location:main.php");
	exit;
}
else {
	exec('echo "update data validation" >> /home/pi/update_log.log');
}

exec ('sudo tar -xzvf update-gateway/update.tar -C update-gateway', $script, $ret);
if ($ret != 0) {
	exec('echo "decompression failed" >> /home/pi/update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	header("Location:main.php");
	exit;
}
else {
	exec('echo "decompressing update-file" >> /home/pi/update_log.log');
}

exec ('sudo sh update-gateway/update-script.sh', $script, $ret);
if ($ret != 0) {
	exec('echo "update failed" >> /home/pi/update_log.log');
	echo exec ("sudo rm -rf update-gateway");
	header("Location:main.php");
	exit;
}
else {
	exec('echo "update successfully installed" >> /home/pi/update_log.log');
}

echo exec ("sudo rm -rf update-gateway");
header("Location:main.php");

exit;

?>
