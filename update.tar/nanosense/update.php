<?php
$git = array();
$script = array();
$ret = 0;
chdir('/home/pi/');
$json = file_get_contents('Nano-Setting.json');
$jsondecode = json_decode($json, true);
$auto_update = NULL;
foreach ($jsondecode AS $key => $value){
    if ($key == 'auto-update'){
        $auto_update = (int)$value;
    }
}

if ($auto_update == 1){
    exec('sudo echo "$(date): starting update" >> update.log');
    exec('sudo git clone --single-branch --branch dev https://github.com/Nanosense92/update-gateway.git update-gateway/', $git, $ret);
    if ($ret != 0){
        exec('sudo echo "$(date): git clone error" >> update.log');
        echo exec('sudo rm -rf update-gateway/');
        exit;
    }
    else{
        exec('sudo echo "$(date): repository cloned" >> update.log');
    }
    exec("sudo dos2unix update-gateway/shasum.txt 2> /dev/null");
    exec("bash -c 'diff <(shasum update-gateway/update.tar) update-gateway/shasum.txt'", $script, $ret);
    if ($ret != 0){
        exec('sudo echo "$(date): corrupted data in update" >> update.log');
        echo exec('sudo rm -rf update-gateway/');
        header('Location:main.php');
        exit;
    }
    else{
        exec('sudo echo "$(date): data validated" >> update.log');
    }

    exec('sudo tar -xzvf update-gateway/update.tar -C update-gateway/', $script, $ret);
    if ($ret != 0){
        exec('sudo echo "$(date): decompression failed" >> update.log');
        echo exec('sudo rm -rf update-gateway/');
        header('Location:main.php');
        exit;
    }
    else{
        exec('sudo echo "$(date): decompressing update archive" >> update.log');
    }

    exec('sudo sh update-gateway/update-script.sh', $script, $ret);
    if ($ret != 0){
        exec('sudo echo "$(date): update script failed" >> update.log');
        echo exec ('sudo rm -rf update-gateway/');
        header('Location:main.php');
        exit;
    }
    else{
        exec('sudo echo "$(date): update successfully installed" >> update.log');
    }

    echo exec('sudo rm -rf update-gateway/');
}
else{
    exec('sudo echo "$(date): auto-update disable" >> update.log');
}

exec('sudo echo "$(date): rebooting system in 10 seconds" >> update.log');
header('Location:main.php');
?>
