<?php
echo nl2br(file_get_contents("/var/www/html/nanosense/change_log.log"));
?>
