<?php

exec("/home/pi/backup/backup-script.sh");


header("Location:main.php");
?>
