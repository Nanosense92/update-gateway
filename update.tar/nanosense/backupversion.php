<?php

exec('sudo /home/pi/backup/backup-script.sh');


header('Location:main.php');
?>
