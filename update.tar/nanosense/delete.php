<?php
/*
 * script to delete line in nanodb which contain reference for http post
 * */
$id = "";
$db = mysqli_connect('localhost', 'jeedom', '85522aa27894d77', 'jeedom');// connect to the database
if($db->connect_errno){
	echo "connection to db failed"; 
    exit;
}

// delete a registered db
if (isset($_GET['deleteid'])){
	$id = mysqli_real_escape_string($db, $_GET['deleteid']);
}
if ($id != ""){
	$delquery = "DELETE FROM nanodb WHERE id='". $id . "'";
	$dblog = mysqli_query($db, $delquery);
	header("Location:main.php");
	exit;
}
?>
