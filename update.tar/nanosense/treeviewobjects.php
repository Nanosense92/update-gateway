<?php
/*
 * script that display the tree view of the different objects
 * */
$db = mysqli_connect('localhost', 'jeedom', '85522aa27894d77', 'jeedom');
if ($db->connect_errno){
    printf('connection failed to db');
    exit;
}

$query = "SELECT o.id, o.name AS name, f.name AS father_name FROM object o LEFT JOIN object f ON o.father_id = f.id";
$res = $db->query($query);
$array = $res->fetch_all(MYSQLI_NUM);

?>
<!DOCTYPE HTML>
<html>
    <head>
        <style>
        .raw {
            display: flex;
        }
        .topleft {
            position: absolute;
            top: 0px;
            left: 0px;
        }
        .padding {
            padding-top: 50px;
            margin: 100px;
        }
        </style>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">
        google.charts.load('current', {packages:["orgchart"], callback: drawChart});
        
        function drawChart(){
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Name');
            data.addColumn('string', 'Father name');
            var array_data = <?php echo json_encode($array)?>;
            array_data.forEach(addData);

            function addData(node){
                data.addRows([[node[1], node[2]]]);
            }

            var options = {
                title: 'Tree view : objects created in Jeedom',
                    
                allowCollapse: true,
                allowHtml: true,
                size: 'small',
            };

            var chart = new google.visualization.OrgChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        }
        </script>

        <title>Tree view : objects created in Jeedom</title>
        <div class="raw">
            <div class="topleft">
                <a href="main.php">
                    <img src="logo-nano.png">
                </a>
            </div>
        </div>
            <center>
                <a href="treeviewobjects.php">
                    <img src="nano-header.png" width="322" height="63">
                </a>
            </center> 

    </head>
    <body>
        <div id="chart_div"></div>
    </body>
</html>
