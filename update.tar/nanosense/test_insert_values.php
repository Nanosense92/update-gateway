<?php
/*
 * script that insert some values in the db to test the different scripts that display the charts
 * */
$db = mysqli_connect('localhost','jeedom','85522aa27894d77','jeedom');
if ($db->connect_errno){
    printf("connection failed");
    exit;
}

$start_datetime = new DateTime("2019-01-01 00:00:00");
$end_datetime = new DateTime("2019-10-08 23:59:59");

$datetime = $start_datetime;

while($datetime < $end_datetime)
{
    $query = "INSERT INTO historyArch VALUES (347, '" . $datetime->format('Y-m-d H:i:s') . "', " . rand(0, 40) . ")";
    echo $query;
    $db->query($query);
    $datetime->add(new DateInterval('PT30S'));
}

?>
