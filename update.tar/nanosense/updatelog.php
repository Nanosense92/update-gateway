<?php
echo nl2br(file_get_contents("update_log.log"));
?>
