<?php
echo nl2br(file_get_contents('/home/pi/update_log.log')); ?>
<!DOCTYPE html>
<html>
    <head>
        <title> Update log </title>
    </head>
</html>
