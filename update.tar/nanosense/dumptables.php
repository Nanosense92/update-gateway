<?php
/*
 * script that dump all jeedom db tables in a file to backup the db
 */
$output = array();
if (isset($_POST['filename'])){
    $filename = $_POST['filename'];
    $ret = 0;
    exec("sudo mysqldump jeedom > $filename.sql", $output, $ret);
    exec("sudo mv $filename.sql /home/pi/");
    exec("chown pi:pi /home/pi/$filename.sql");
    exec("chmod 775 /home/pi/$filename.sql");
    header('Location:main.php');
}
?>
