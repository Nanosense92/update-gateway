<?php
if (isset($_POST['save_config'])){
    $auto_update = $_POST['auto-update'];
    $timezone_offset = $_POST['timezone-offset'];
    $send_data_interval = $_POST['send-data-interval'];
    
    $jsoncontents = file_get_contents('/home/pi/Nano-Setting.json');
    $json = json_decode($jsoncontents, true);
    foreach($json AS $key => $value){
        if ($key == 'timezone'){
            $json[$key] = $timezone_offset;
        }
        else if ($key == 'send-data-interval'){
            $json[$key] = $send_data_interval;
        }
        else if ($key == 'auto-update'){
            if ($auto_update == 'true'){
                $json[$key][0] = 1;
            }
            else{
                $json[$key][0] = 0;
            }
        }
    }
    $newjsoncontents = json_encode($json, JSON_PRETTY_PRINT);
    file_put_contents('/home/pi/Nano-Setting.json', $newjsoncontents . PHP_EOL);

    header('Location:main.php');
}
?>
