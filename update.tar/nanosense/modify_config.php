<?php
if (isset($_POST['save_config'])){
    // get the 3 parameters of the firmware configuration
    $auto_update = $_POST['auto-update'];
    $timezone_offset = $_POST['timezone-offset'];
    $send_data_interval = $_POST['send-data-interval'];
    $average_mode = $_POST['average-mode'];

    // get json file contents in a json object
    $jsoncontents = file_get_contents('/home/pi/Nano-Setting.json');
    $json = json_decode($jsoncontents, true);
    
    // change the parameters in the json object
    foreach($json AS $key => $value){
        if ($key == 'timezone'){
            $json[$key] = $timezone_offset;
        }
        else if ($key == 'send-data-interval'){
            $json[$key] = $send_data_interval;
        }
        else if ($key == 'auto-update'){
            if ($auto_update == 'true'){
                $json[$key][0] = 1;
            }
            else{
                $json[$key][0] = 0;
            }
        }
        else if ($key == 'average-mode'){
            if ($average_mode == 'true'){
                $json[$key][0] = 1;
            }
            else{
                $json[$key][0] = 0;
            }
        }
    }
    
    // rewrite the json object in the json file
    $newjsoncontents = json_encode($json, JSON_PRETTY_PRINT);
    file_put_contents('/home/pi/Nano-Setting.json', $newjsoncontents . PHP_EOL);
    
    // modify crontab file
    $sed_command = 'sudo sed -Ei \'s/(\*\/)[[:digit:]]*\ (\*\ )\2\2\2(php \/home\/pi\/enocean-gateway\/getdata\.php\ >>\ \/dev\/null)/\1' . $send_data_interval . '\ \2\2\2\2\3/\' /var/spool/cron/crontabs/pi';
    exec($sed_command);

    // reload crontab file
    exec('sudo crontab -u pi -l | sudo crontab -u pi -');

    header('Location:main.php');
}
?>
