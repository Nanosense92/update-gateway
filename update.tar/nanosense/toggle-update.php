<?php
$toggle = (int)nl2br(file_get_contents("/home/pi/update_status.cfg"));
echo $toggle;
if ($toggle == 0)
{
	exec("echo '1' > /home/pi/update_status.cfg");
}
else
{
	exec("echo '0' > /home/pi/update_status.cfg");
}

header("Location:main.php");
?>
