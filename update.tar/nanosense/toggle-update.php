<?php

$strJsonFileContents = file_get_contents('/home/pi/Nano-Setting.json');
$array = json_decode($strJsonFileContents, true);
foreach($array AS $key => $value){
    if($key == 'auto-update'){
        if($value == '0'){
            $array[$key][0] = 1;}
        else
            $array[$key][0] = 0;
    }
}
$newjson = json_encode($array, JSON_PRETTY_PRINT);
file_put_contents('/home/pi/Nano-Setting.json', $newjson);

header('Location:main.php');
?>
