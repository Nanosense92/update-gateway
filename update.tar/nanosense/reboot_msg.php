<h4> The gateway is rebooting, it should be up in 5 to 10 minutes </h4> 

