DELETE FROM nanodb WHERE addr="http://nsapi.pando2.fr";

