#!/bin/sh

LOG='/home/pi/update.log'
TRASH='/dev/null'

sudo echo "$(date): starting restore backup script" >> $LOG;

CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)
PREVVERS=$(cat /home/pi/backup/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

sudo echo "current version: " $CURVERS
sudo echo "previous version: " $PREVVERS

sudo echo "$(date): going back to version" $PREVVERS "from version" $CURVERS >> $LOG;
sudo echo "$(date): restoring the backup of the firmware and its configuration" >> $LOG;

# check backup folder existence
ERROR=$((sudo ls backup/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi

# restore firmware configuration
ERROR=$((sudo mv -f /home/pi/backup/Nano-Setting.json /home/pi/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while restoring the firmware configuration" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi

# restore crontab file
ERROR=$((sudo mv -f /home/pi/backup/crontabs/pi /var/spool/cron/crontabs/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while restoring the crontab file" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi
# reload crontab file
ERROR=$((sudo crontab -l -u pi | crontab -u pi -) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while reloading the crontab file" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi

# restore data push scripts and routines
ERROR=$((sudo rm -rf /home/pi/enocean-gateway/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while removing the actual data push scripts" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi
ERROR=$((sudo mv -f /home/pi/backup/enocean-gateway/ /home/pi/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while restoring the data push scripts" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi

# restore web-interface
ERROR=$((sudo rm -rf /var/www/html/nanosense/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while removing the actual web-interface" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi
ERROR=$((sudo mv -f /home/pi/backup/nanosense/ /var/www/html/) 2>&1)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error while restoring the web-interface" >> $LOG;
    sudo echo "$(date): error: $ERROR" >> $LOG;
    exit $RET
fi

sudo rm -rf /home/pi/backup/ 2>> $TRASH;
sudo echo "$(date): backup of version" $PREVVERS "correctly restored" >> $LOG;
