#!/bin/sh
sudo echo "$(date): starting restore backup script" >> /home/pi/update.log;

CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)
PREVVERS=$(cat /home/pi/backup/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

sudo echo "current version: " $CURVERS
sudo echo "previous version: " $PREVVERS

sudo echo "$(date): going back to version " $PREVVERS " from version " $CURVERS >> /home/pi/update.log
sudo echo "$(date): restoring the backup of the firmware and its configuration" >> /home/pi/update.log

# restore firmware version and configuration
sudo mv -f /home/pi/backup/Nano-Setting.json /home/pi/

# restore crontab file
sudo mv -f /home/pi/backup/crontabs/pi /var/spool/cron/crontabs/
sudo crontab -l -u pi | crontab -u pi -

# restore data push scripts and routines
sudo mv -f /home/pi/backup/enocean-gateway/ /home/pi/

# restore web-interface
sudo mv -f /home/pi/backup/nanosense/ /var/www/html/

sudo echo "$(date): backup correctly restored" >> /home/pi/update.log
