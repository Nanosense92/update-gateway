#!/bin/sh

sudo chmod +x /usr/local/bin/uninstall-log2ram.sh
sudo /usr/local/bin/uninstall-log2ram.sh

