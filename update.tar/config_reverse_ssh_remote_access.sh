#!/bin/bash

LOG='/var/log/update.log'
TRASH='/dev/null'

# add ssh configuration in /etc/ssh/ssh_config
ERROR=$(sudo cat /etc/ssh/ssh_config | grep "TCPKeepAlive" 2>&1 1>>$TRASH)
RET=$?
if [ $RET -gt 0 ]
then
    echo "    TCPKeepAlive yes" | sudo tee -a /etc/ssh/ssh_config >> $TRASH
    echo "    ServerAliveCountMax 3" | sudo tee -a /etc/ssh/ssh_config >> $TRASH
    echo "    ServerAliveInterval 15" | sudo tee -a /etc/ssh/ssh_config >> $TRASH
    echo "    ExitOnForwardFailure yes" | sudo tee -a /etc/ssh/ssh_config >> $TRASH
fi

# generate private ssh key (id_rsa) in /home/pi/.ssh/
ERROR=$(sudo find $HOME/.ssh/ 2>&1 1>> $TRASH)
RET=$?
if [ $RET -gt 0 ]
then
    sudo mkdir $HOME/.ssh/ >> $TRASH
else
    ERROR=$(sudo find $HOME/.ssh/id_rsa 2>&1 1>> $TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        ssh-keygen -t rsa -f $HOME/.ssh/id_rsa -q -N ''
    fi
fi

# install autossh
ERROR=$(sudo apt-get install autossh 2>&1 1>>$TRASH)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error: $ERROR" >> $LOG
    exit $RET
fi

# configure autossh
ERROR=$(sudo cat /etc/crontab | grep "autossh" 2>&1 1>>$TRASH)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "@reboot         root    export AUTOSSH_POLL=30; /usr/lib/autossh/autossh -M 20000 -C -N -f -n -T -p 2200 -i /home/pi/.ssh/id_rsa -R \*:8080:localhost:80 -R \*:2222:localhost:22 pi@82.64.155.200" | sudo tee -a /etc/crontab 2>&1 1>>$TRASH
fi

# install ssmtp
ERROR=$(sudo apt-get install mailutils ssmtp 2>&1 1>>$TRASH)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "$(date): error: $ERROR" >> $LOG
    exit $RET
fi

# configure ssmtp
SSMTP_CONFIG_FILE=/etc/ssmtp/ssmtp.conf

ERROR=$(sudo cat $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH)
RET=$?
if [ $RET -eq 0 ]
then
    ERROR=$(sudo cat $SSMTP_CONFIG_FILE | grep "UseSTARTTLS" 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo perl -0777 -pi -e 's/(root=).*/\1pi/' $SSMTP_CONFIG_FILE
        sudo perl -0777 -pi -e 's/(mailhub=).*/\1smtp.gmail.com:587/' $SSMTP_CONFIG_FILE
        sudo echo "" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH
        sudo echo "UseTLS=YES" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH
        sudo echo "UseSTARTTLS=YES" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH
        sudo echo "FromLineOverride=YES" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH
        sudo echo "AuthUser=nanosense.dev.raspberrypi@gmail.com" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH
        sudo echo "AuthPass=Nanosense92!" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH
        sudo echo "AuthMethod=LOGIN" | sudo tee -a $SSMTP_CONFIG_FILE 2>&1 1>>$TRASH 
    fi
else
    sudo echo "$(date): error: $ERROR" >> $LOG
    exit $RET
fi

EMAIL=$HOME/email
ERROR=$(find $EMAIL 2>&1 1>>$TRASH)
RET=$?
if [ $RET -gt 0 ]
then
    sudo echo "To:cantin@nano-sense.com"
    sudo echo "Subject: EnOcean/IP Gateway: hardware and software informations" >> $EMAIL

    FIRMWARE_VERSION=$(cat $HOME/Nano-Setting.json | grep "version" | cut -d '"' -f 4)
    sudo echo "Firmware version: $FIRMWARE_VERSION" >> $EMAIL

    sudo echo "" >> $EMAIL

    DISK_SPACE_USAGE=$(df -h)
    sudo echo -e "Current disk space usage:\n $DISK_SPACE_USAGE" >> $EMAIL
    
    JEEDOM_ACCOUNT=$(sudo mysql jeedom -N -s -e "SELECT \`value\` FROM \`config\` WHERE \`key\` = 'market::username'")
    sudo echo "Current Jeedom market account: $JEEDOM_ACCOUNT" >> $EMAIL

    sudo echo "" >> $EMAIL

    ENOCEAN_EQUIPMENTS=$(sudo mysql -Bt jeedom -e "SELECT \`eqLogic\`.\`name\` AS 'eqLogic_name',
        \`eqLogic\`.\`logicalId\`, \`object\`.\`name\` AS 'object_name' FROM \`eqLogic\`, \`object\`
        WHERE \`eqLogic\`.\`object_id\` = \`object\`.\`id\` AND \`eqLogic\`.\`logicalId\` != \"\"")
    sudo echo -e "EnOcean equipments list:\n $ENOCEAN_EQUIPMENTS" >> $EMAIL 
   
    sudo echo "" >> $EMAIL

    PUBLIC_KEY=$(cat $HOME/.ssh/id_rsa.pub)
    sudo echo -e "Public RSA key:\n $PUBLIC_KEY" >> $EMAIL

    sudo echo "" >> $EMAIL

    LINE_CRONTAB=$(sudo cat /etc/crontab | grep "autossh")
    sudo echo "Autossh line crontab: $LINE_CRONTAB" >> $EMAIL

    sudo echo "" >> $EMAIL

    ETH0_MAC_ADDR=$(sudo ifconfig | awk '/eth0/,/^$/' | grep -a 'ether' | cut -d ' ' -f 10)
    sudo echo "Eth0 MAC address: $ETH0_MAC_ADDR" >> $EMAIL

    sudo echo "" >> $EMAIL

    WLAN0_MAC_ADDR=$(sudo ifconfig | awk '/wlan0/,/^$/' | grep -a 'ether' | cut -d ' ' -f 10)
    sudo echo "Wlan0 MAC address: $WLAN0_MAC_ADDR" >> $EMAIL

    sudo echo "" >> $EMAIL

    PRIVATE_IP_ADDR=$(sudo ifconfig | awk '/eth0/,/^$/' | grep -a 'inet ' | cut -d ' ' -f 10)
    if [ "$PRIVATE_IP_ADDR" == "" ]
    then
        PRIVATE_IP_ADDR=$(sudo ifconfig | awk '/wlan0/,/^$/' | grep -a 'inet ' | cut -d ' ' -f 10)
    fi
    sudo echo "Private IPv4 address: $PRIVATE_IP_ADDR" >> $EMAIL

    sudo echo "" >> $EMAIL

    PUBLIC_IP_ADDR=$(sudo wget -qO- https://ipecho.net/plain ; echo)
    sudo echo "Public IPv4 address: $PUBLIC_IP_ADDR" >> $EMAIL

    sudo echo "" >> $EMAIL

    ERROR=$(sendmail < $EMAIL)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error: $ERROR" >> $LOG
        exit $RET
    fi
fi

