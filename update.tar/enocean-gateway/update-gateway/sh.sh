#!/bin/sh

# cpoy the script in the update-gateway repo then run it

tar -xzf update.tar
rm -rf nanosense enocean-gateway
OUTPUT="$(cat version-update.txt)"
OUTPUT=$((OUTPUT+1))
echo $OUTPUT > version-update.txt
rm update.tar
cp -rf /var/www/html/nanosense ./
cp -rf /home/pi/enocean-gateway ./
tar -czf update.tar nanosense enocean-gateway version-update.txt update-script.sh
echo "create compressed file in: update.tar"
(cd .. && shasum update-gateway/update.tar > update-gateway/shasum.txt)
rm -rf version-update.txt update-script.sh nanosense enocean-gateway
