sécurisé le clone en compressant l'update et en envoyant un fichier contenant le CHEKSUM
comparer le CHECKSUM ET LE FICHER pour avoir la validité du transfert.
