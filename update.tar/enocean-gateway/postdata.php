<?php
/*
 * FILE : postdata.php
 */

include 'getsettings.php';
include 'httprequest.php';

function setpollutant($pollutant){
    if ($pollutant == 'PM2.5')
        return 'PM2_5';
    if (strpos($pollutant, 'Temp') !== false)
        return 'TMP';
    if (strpos($pollutant, 'Hum') !== false)
        return 'HUM';
    if (strpos($pollutant, 'Total') !== false)
        return 'VOC';
    else
        return $pollutant;
}

$logfile = fopen('/var/log/postdata.log', 'a');
$errorlogfile = fopen('/var/log/postdata_error.log', 'a');

/*
 * Query on the jeedom database that get, for each cmd of each equipment,
 * the last value saved in history 
 */
$last_val_query = "SELECT `eqLogic`.`name` AS 'alias', `eqLogic`.`logicalId`, " 
    . "`cmd`.`name`, MAX(`history`.`datetime`) AS 'max_datetime', `cmd`.`id`, "
    . "`object`.`name` AS 'object_name' FROM `history`, `cmd`, `eqLogic`, `object` "
    . "WHERE `history`.`cmd_id` = `cmd`.`id` AND `cmd`.`eqLogic_id` = `eqLogic`.`id` "
    . "AND `eqLogic`.`object_id` = `object`.`id` "
    . "AND `datetime` > ADDTIME(NOW(), '$offset') GROUP BY cmd.id";
$last_val_cmd_query = $dbconnect->query($last_val_query);

/*
 * Formating the data to send a correct JSON file
 */
$table = array();
while ($last_val_row = $last_val_cmd_query->fetch_array(MYSQLI_BOTH)){
    fwrite($logfile, date('Y-m-d H:i:s') . "\t");
    $value_array = array();

    $pollutant = setpollutant($last_val_row[2]);
    fwrite($logfile, $last_val_row[0] . '-' . $pollutant . "\n");

    if ($average_mode == 1){ // AVERAGE MODE

        /* 
         * Query to get the average value of one cmd within the last
         * "$send_data_interval" minutes
         */
        $avg_val_query = "SELECT `cmd_id`, MAX(`datetime`) AS 'max_datetime', "
            . "AVG(`value`) AS 'average_value' FROM `history` WHERE "
            . "`cmd_id` = '$last_val_row[4]' AND `datetime` >= ADDTIME(NOW(), '$offset')";
        $avg_val_cmd_query = $dbconnect->query($avg_val_query);
        
        $avg_val_row = $avg_val_cmd_query->fetch_array(MYSQLI_BOTH);
        $last_datetime = $avg_val_row[1];
        $avg_value = $avg_val_row[2];

        // Build the main array that will contain all the values for one pollutant
        $value_array[] = array(
            'at' => date('Y-m-d\TH:i:s\Z',
                strtotime($last_datetime . '-' . $timezone_offset . 'hours')),
            'value' => $avg_value
        );
        //var_dump($value_array);
    }
    else{ // NORMAL MODE
        
        /*
         * Query to get all the values of one cmd within the last
         * "$send_data_interval" minutes
         */
        $val_query = "SELECT * FROM `history` WHERE "
            . "`cmd_id` = '$last_val_row[4]' AND "
            . "`datetime` >= ADDTIME(NOW(), '$offset')";
        $val_cmd_query = $dbconnect->query($val_query);
        
        while ($val_row = $val_cmd_query->fetch_array(MYSQLI_BOTH)){
            // Build the main array that will contain all the values for one pollutant
            $value_array[] = array(
                'at' => date('Y-m-d\TH:i:s\Z',
                    strtotime($val_row[1] . '-' . $timezone_offset . 'hours')),
                'value' => $val_row[2]
            );
            //var_dump($value_array);
        }
    }

    // Build the header of the JSON
    $table['version'] = '1.0.0';
    $table['datastreams'] = array(
        array(
            'alias' => $last_val_row[0] . '-' . $pollutant,
            'location' => $last_val_row[5],
            'pollutant' => $last_val_row[2],
            'id' => $last_val_row[1],
            'datapoints' => $value_array
        )
    );

    // HTTP request with database query
    http_request($dbconnect, $logfile, $table, $last_val_row[0], $pollutant,
        $errorlogfile);
}
fclose($logfile);
fclose($errorlogfile);
mysqli_close($dbconnect);
?>
