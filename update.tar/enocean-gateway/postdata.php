<?php
/*
 * FILE : postdata.php
 */

include 'getsettings.php';
include 'httprequest.php';
include 'misc.php';

// the main log file (contains all the successfully sent IAQ data)
$logname = '/var/log/postdata.log';
$logfile = fopen($logname, 'a') or die('Cannot open file: ' . $logname . "\n");
// the error log file (contains all the IAQ data not sent)
$errorlogname = '/var/log/postdata_error.log';
$errorlogfile = fopen($errorlogname, 'a') or die('Cannot open file: ' . $errorlogname . "\n");

/*
 * Query on the jeedom database that get, for each command (CO2, Temperature, PM, ...)
 * of each equipment, the last value saved in history 
 */
$last_val_query = "SELECT `eqLogic`.`name` AS 'alias', `eqLogic`.`logicalId`, " 
    . "`cmd`.`name`, MAX(`history`.`datetime`) AS 'max_datetime', `cmd`.`id`, "
    . "`object`.`name` AS 'object_name' FROM `history`, `cmd`, `eqLogic`, `object` "
    . "WHERE `history`.`cmd_id` = `cmd`.`id` AND `cmd`.`eqLogic_id` = `eqLogic`.`id` "
    . "AND `eqLogic`.`object_id` = `object`.`id` "
    . "AND `datetime` > ADDTIME(NOW(), '$offset') GROUP BY cmd.id";
$last_val_cmd_query = $dbconnect->query($last_val_query);

/*
 * Formating the data to send a correct JSON file
 */
$table = array();
while ($last_val_row = $last_val_cmd_query->fetch_array(MYSQLI_BOTH)){
    fwrite($logfile, date('Y-m-d H:i:s') . "\t");
    $value_array = array();

    $equipment_alias = $last_val_row[0];
    $equipment_ID = $last_val_row[1];
    $command_name = $last_val_row[2];
    $command_ID = $last_val_row[4];
    $object_name = $last_val_row[5];

    $pollutant = setpollutant($command_name); // set the pollutant name
    fwrite($logfile, $equipment_alias . '-' . $pollutant . "\n");

    if ($average_mode == 1){ // AVERAGE MODE

        /* 
         * Query to get the average value of one cmd within the last
         * "$send_data_interval" minutes
         */
        $avg_val_query = "SELECT `cmd_id`, MAX(`datetime`) AS 'max_datetime', "
            . "AVG(`value`) AS 'average_value' FROM `history` WHERE "
            . "`cmd_id` = '$command_ID' AND `datetime` >= ADDTIME(NOW(), '$offset')";
        $avg_val_cmd_query = $dbconnect->query($avg_val_query);
        
        $avg_val_row = $avg_val_cmd_query->fetch_array(MYSQLI_BOTH);
        $last_datetime = $avg_val_row[1];
        $avg_value = $avg_val_row[2];

        // Build the main array that will contain all the values for one pollutant
        $value_array[] = array(
            'at' => date('Y-m-d\TH:i:s\Z',
                strtotime($last_datetime . '-' . $timezone_offset . 'hours')),
            'value' => $avg_value
        );
        //var_dump($value_array);
    }
    else{ // NORMAL MODE
        
        /*
         * Query to get all the values of one cmd within the last
         * "$send_data_interval" minutes
         */
        $val_query = "SELECT * FROM `history` WHERE "
            . "`cmd_id` = '$command_ID' AND "
            . "`datetime` >= ADDTIME(NOW(), '$offset')";
        $val_cmd_query = $dbconnect->query($val_query);
        
        while ($val_row = $val_cmd_query->fetch_array(MYSQLI_BOTH)){
            $datetime = $val_row[1];
            $value = $val_row[2];

            // Build the main array that will contain all the values for one pollutant
            $value_array[] = array(
                'at' => date('Y-m-d\TH:i:s\Z',
                    strtotime($datetime . '-' . $timezone_offset . 'hours')),
                'value' => $value
            );
            //var_dump($value_array);
        }
    }

    // Build the header of the JSON
    $table['version'] = '1.0.0';
    $table['datastreams'] = array(
        array(
            'alias' => $equipment_alias . '-' . $pollutant,
            'location' => $object_name,
            'pollutant' => $command_name,
            'id' => $equipment_ID,
            'datapoints' => $value_array
        )
    );
    
    // Encode the newly formatted table into a PHP json object
    $jsondata = json_encode($table, JSON_PRETTY_PRINT);
    
    // HTTP request with database query
    http_request($dbconnect, $logfile, $jsondata, $equipment_alias, $pollutant,
        $errorlogfile);
}

// close all the currently opened resources
fclose($logfile);
fclose($errorlogfile);
mysqli_close($dbconnect);
?>
