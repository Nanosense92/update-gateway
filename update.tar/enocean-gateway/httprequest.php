<?php
function http_request($dbconnect, $log, $json_table, $location, $data, $errlog){ 
    $http_query = $dbconnect->query('SELECT * FROM nanodb');
    while ($http_row = $http_query->fetch_array(MYSQLI_BOTH)){

        $auth = $http_row['location'];
        $url = $http_row['addr'];
        $login = $http_row['login'];
        $pass = $http_row['password'];

        if ($http_row['port'] != NULL)
            $url = $url . ':' . $http_row['port'];
        if ($http_row['path'][0] != '/')
            $url = $url . '/' . $http_row['path'];
        else
            $url = $url . $http_row['path'];

        fwrite($log, $url . "\t");

        $ch = curl_init($url);
        $jsondata = json_encode($json_table, JSON_PRETTY_PRINT);

        /*
         *  Set the HTTP Post request with CURL
         */
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Token: ' . $auth,
        )); 
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_USERPWD, "$login:$pass");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true); //debug
        $curl_res = curl_exec($ch);

        /* DEBUG */
            $headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT );
            var_dump(curl_getinfo($ch, CURLINFO_HTTP_CODE));
            var_dump($headerSent);
            echo $jsondata . "\n";
        /* DEBUG */

        fwrite($log, $curl_res . "\n");

        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpcode >= 400){
            $error_msg = date('Y-m-d H:i:s') . ' '
                . $location . ' ' . $data
                . $url . ' ' . $httpcode . "\n";
            fwrite($errlog, $error_msg);
        }
        if (curl_errno($ch)){
            echo 'CURL error: '. curl_error($ch);
        }

        curl_close($ch);
    }
}
?>
