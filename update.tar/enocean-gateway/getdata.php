<?php
$json = file_get_contents('/home/pi/Nano-Setting.json');
$jsondecode = json_decode($json, true);
$offset = 0;
$timezone_offset = 0;
$send_data_interval = 0;
foreach($jsondecode AS $key => $value){
    if ($key == 'timezone'){
        $timezone_offset = (int)$value;
    }
    if ($key == 'send-data-interval'){
        $send_data_interval = (int)$value;
    }
}

if ($timezone_offset > 0){
    $offset = ($timezone_offset - 1) . ':' . (60 - $send_data_interval) . ':00';
}
else{
    $offset = '-' . ($timezone_offset) . ':' . (60 - $send_data_interval) . ':00';
}

/*
 * Database identification
 */
$hostname = 'localhost';
$username = 'jeedom';
$password = '85522aa27894d77';
$db = 'jeedom';

// Connect to the database
$dbconnect = mysqli_connect($hostname, $username, $password, $db);
if ($dbconnect->connect_errno){
    printf('connect failed');
    exit;
}

$logfile = fopen('/home/pi/getdata.log', 'w');

/*
 * Query on the jeedom database that get, for each cmd of each equipment, the last value saved in history 
 */
$val_cmd_query = $dbconnect->query("SELECT `eqLogic`.`name` AS 'alias', `eqLogic`.`logicalId`, `cmd`.`name`, " .
    "MAX(`history`.`datetime`), `cmd`.`id` FROM `history`, `cmd`, `eqLogic` WHERE `history`.`cmd_id` = `cmd`.`id` " .
    "AND `cmd`.`eqLogic_id` = `eqLogic`.`id` AND `datetime` > ADDTIME(NOW(), '$offset') GROUP BY cmd.id");
/*
 * Formating the data to send a correct JSON file
 */
$table = array();

$pollutant = '';
while ($val_cmd_row = $val_cmd_query->fetch_array(MYSQLI_BOTH)) {
    fwrite($logfile, date('Y-m-d H:i:s') . "\t");
    $value_array = array();
    if ($val_cmd_row[2] == 'PM2.5')
        $pollutant = 'PM2_5';
    else if (strpos($val_cmd_row[2], 'Temp') !== false)
        $pollutant = 'TMP';
    else if (strpos($val_cmd_row[2], 'Hum') !== false)
        $pollutant = 'HUM';
    else if (strpos($val_cmd_row[2], 'Total') !== false)
        $pollutant = 'VOC';
    else
        $pollutant = $val_cmd_row[2];
    fwrite($logfile, $val_cmd_row[0] . '-' . $pollutant . "\n");
    
    // Query to get all the values of one cmd within the last "$send_data_interval" minutes
    $value_query = $dbconnect->query("SELECT * FROM `history` WHERE `cmd_id` = '$val_cmd_row[4]' AND `datetime` >= ADDTIME(NOW(), '$offset')");
    while ($value_line = $value_query->fetch_array(MYSQLI_BOTH)){
    	// Build the main array that will contain all the values for one pollutant
    	$value_array[] = array(
	    'at' => date('Y-m-d\TH:i:s\Z', strtotime($value_line[1] . '-' . $timezone_offset . 'hours')),
            'value' => $value_line[2]
    	);
    	//var_dump($value_array);
    }

    // Build the header of the JSON
    $table['version'] = '1.0.0';
    $table['datastreams'] = array(
        array(
            'alias'=> $val_cmd_row[0] . '-' . $pollutant,
            'location'=> '',
            'pollutant'=> $val_cmd_row[2],
            'id'=> $val_cmd_row[1],
            'datapoints' => $value_array
        )
    );

    // HTTP request with database query
    $http_res = $dbconnect->query('SELECT * FROM `nanodb`');
    while ($httpreq = $http_res->fetch_array(MYSQLI_BOTH)) {
        $auth = $httpreq['location'];
        $table['datastreams'][0]['location'] = $httpreq['location'];
        $url = $httpreq['addr'];
        if ($httpreq['port'] != NULL)
            $url = $url . ':' . $httpreq['port'];
        if ($httpreq['path'][0] != '/')
            $url = $url . '/' . $httpreq['path'];
        else
            $url = $url . $httpreq['path'];
        fwrite($logfile, $url . "\t");
        $ch = curl_init($url);
        $login = $httpreq['login'];
        $pass = $httpreq['password'];
        $jsondata = json_encode($table, JSON_PRETTY_PRINT);
        
        /*
         * Set the HTTP POST REQUEST with CURL
         */
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Token:'. ' ' . $auth,
        ));
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_USERPWD, "$login:$pass");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);//debug
        $res = curl_exec($ch);
    
        /* DEBUG */
        /* 
        $headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT );
        var_dump(curl_getinfo($ch, CURLINFO_HTTP_CODE));
        var_dump($headerSent);
        echo $jsondata . "\n";
        */
        /* DEBUG */

        fwrite($logfile, $res . "\n");
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpcode >= 400){
            $errorlog = fopen('/home/pi/getdata_error.log', 'a');
            fwrite($errorlog ,date('Y-m-d H:i:s'). ' ' . $val_cmd_row[0] . ' ' . $pollutant .' '. $url . ' '. $httpcode. "\n");
            fclose($errorlog);
        }
        if (curl_errno($ch)){
            echo 'error: ' . curl_error($ch);
        }
        curl_close($ch);
    }
}
fwrite($logfile, "\n");
fclose($logfile);
mysqli_close($dbconnect);
?>
