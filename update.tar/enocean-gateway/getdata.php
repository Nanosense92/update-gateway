<?php
$json = file_get_contents('/home/pi/Nano-Setting.json');
$jsondecode = json_decode($json, true);
$offset = 0;
$dateoffset = 0;
foreach($jsondecode AS $key => $value){
    if ($key == 'timezone'){
	$dateoffset = (int)$value;}
}
if ($offset > 0){
    $offset = ($dateoffset - 1) . ':55:00';
}
else{
    $offset = ($dateoffset) . ':-05:00';
}

/*
 * database identification
 */
$hostname = 'localhost';
$username = 'jeedom';
$password = '85522aa27894d77';
$db = 'jeedom';

$dbconnect = mysqli_connect($hostname, $username, $password, $db);
$logfile = fopen('getdata.log', 'w');
if ($dbconnect->connect_errno){
    printf('connect failed');
    exit;
}

/*
 * Query on the jeedom database to send all the data from Enocean Sensor
 */
$result = $dbconnect->query("SELECT eqLogic.name AS alias, eqLogic.logicalId, cmd.name, " .
	"history.datetime, cmd.id FROM history, cmd, eqLogic WHERE history.cmd_id = cmd.id " .
	"AND cmd.eqLogic_id = eqLogic.id AND datetime > ADDTIME(now(), '". $offset ."') GROUP BY cmd.id");
/*
 * Formating the data to send a correct JSON file
 */
$table = array();

$hotfix = '';
while ($row = $result->fetch_array(MYSQLI_BOTH)) {
    fwrite($logfile, date('Y-m-d H:i:s') . "\t");
    $value_array = array();
    if ($row[2] == 'PM2.5')
	$hotfix = 'PM2_5';
    else if (strpos($row[2], 'Temp') !== false)
	$hotfix = 'TMP';
    else if (strpos($row[2], 'Hum') !== false)
	$hotfix = "HUM";
    else if (strpos($row[2], 'Total') !== false)
	$hotfix = 'VOC';
    else
	$hotfix = $row[2];
    fwrite($logfile, $row[0] . '-' . $hotfix . "\n");
    $idquery = $dbconnect->query("SELECT * FROM history WHERE cmd_id='" . $row[4] . "' AND datetime >= ADDTIME(now(), '". $offset ."')");
    while ($valquery = $idquery->fetch_array(MYSQLI_BOTH)){
	$value_array[] = array(
		'at' => date('Y-m-d\TH:i:s\Z', strtotime($valquery[1] . '-' . $dateoffset . 'hours')),
		'value' => $valquery[2]);
	//	var_dump($value_array);
    }
    $table['version'] = '1.0.0';
    $table['datastreams'] = array(
	    array(
		'alias'=> $row[0] . '-' . $hotfix,
		'location'=> '',
		'pollutant'=> $row[2],
		'id'=> $row[1],
		'datapoints' => $value_array
		)
	    );
    //http request with database query
    $http_res = $dbconnect->query('SELECT * FROM nanodb');
    while ($httpreq = $http_res->fetch_array(MYSQLI_BOTH)) {
	$Auth = $httpreq['location'];
	$table['datastreams'][0]['location'] = $httpreq['location'];
	$url = $httpreq['addr'];
	if ($httpreq['port'] != NULL)
	    $url = $url . ':' . $httpreq['port'];
	if ($httpreq['path'][0] != '/')
	    $url = $url . '/' . $httpreq['path'];
	else
	    $url = $url . $httpreq['path'];
	fwrite($logfile, $url . "\t");
	$ch = curl_init($url);
	$login = $httpreq['login'];
	$pass = $httpreq['password'];
	//		var_dump($url);
	$jsondata = json_encode($table, JSON_PRETTY_PRINT);
	//		echo $row[0] . '-' . $hotfix;
	//		echo "\n";
	/*
	 * Set the HTTP POST REQUEST with CURL
	 */
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		    'Content-Type: application/json',
		    'Token:'. ' ' . $Auth,
		    ));
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_USERPWD, "$login:$pass");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLINFO_HEADER_OUT, true);//debug
	$res = curl_exec($ch);
	/*debug
	  $headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT );
	  var_dump(curl_getinfo($ch, CURLINFO_HTTP_CODE));
	  var_dump($headerSent);
	  debug*/
	echo $jsondata . "\n";
	fwrite($logfile, $res . "\n");
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	if ($httpcode >= 400){
	    $errorlog = fopen('getdata_error.log', 'a');
	    fwrite($errorlog ,date('Y-m-d H:i:s'). ' ' . $row[0] . ' ' . $hotfix .' '. $url . ' '. $httpcode. "\n");
	    fclose($errorlog);
	}
	if (curl_errno($ch))
	{
	    echo 'error:'. curl_error($ch);
	}
	curl_close($ch);
    }
}
fclose($logfile);
mysqli_close($dbconnect);
?>
