<?php
$json = file_get_contents('/home/pi/Nano-Setting.json');
$jsondecode = json_decode($json, true);
$offset = 0;
$dateoffset = 0;
foreach($jsondecode AS $key => $value){
    if ($key == 'timezone'){
	$dateoffset = (int)$value;}
}
if ($offset > 0){
    $offset = ($dateoffset - 1) . ':55:00';
}
else{
    $offset = ($dateoffset) . ':-05:00';
}
#
# database identification
#
$hostname = 'localhost';
$username = 'jeedom';
$password = '85522aa27894d77';
$db = 'jeedom';

$dbconnect = mysqli_connect($hostname, $username, $password, $db);
$logfile = fopen('/home/pi/post_miss.log', 'w');
if ($dbconnect->connect_errno){
    printf('connect failed');
    exit;
}

$backupfile = fopen('/home/pi/getdata_error.log', 'r');
while(! feof($backupfile)){
	$result = fgets($backupfile);
	$pieces = explode(" ", $result);
	if ($pieces[5]){
//var_dump($pieces);
	$Pdate = date('Y-m-d H:i:s', strtotime($pieces[0] . $pieces[1] . '+' . $dateoffset .' hours'));
	echo $Pdate . "\n";
#
# Query on the jeedom database to send all the data from Enocean Sensor
#
$result = $dbconnect->query("SELECT eqLogic.name AS alias, eqLogic.logicalId, cmd.name, " .
	"history.datetime, cmd.id FROM history, cmd, eqLogic WHERE history.cmd_id = cmd.id " .
	"AND cmd.eqLogic_id = eqLogic.id AND eqLogic.name = '" . $pieces[2] . 
	"' AND cmd.name ='" . $pieces[3] . "' GROUP BY cmd.id");
#
# Formating the data to send a correct JSON file
#
$table = array();
$hotfix = '';
while ($row = $result->fetch_array(MYSQLI_BOTH)) {
    fwrite($logfile, date('Y-m-d H:i:s') . "\t");
    $value_array = array();
    if ($row[2] == 'PM2_5')
	$hotfix = 'PM2.5';
    else if (strpos($row[2], 'TMP') !== false)
	$hotfix = 'Température';
    else if (strpos($row[2], 'HUM') !== false)
	$hotfix = "Humidité";
    else if (strpos($row[2], 'VOC') !== false)
	$hotfix = 'Total';
    else
	$hotfix = $row[2];
    fwrite($logfile, $row[0] . '-' . $row[2] . "\n");
    $idquery = $dbconnect->query("SELECT * FROM historyArch WHERE cmd_id='" . $row[4] .
	 "' AND datetime <= '" . $Pdate . "' AND datetime >= SUBTIME('". $Pdate .",00:05:00')");
    while ($valquery = $idquery->fetch_array(MYSQLI_BOTH)){
	var_dump($valquery);
	$value_array[] = array(
		'at' => date('Y-m-d\TH:i:s\Z', strtotime($valquery[1] . '-' . $dateoffset . 'hours')),
		'value' => $valquery[2]);
    }
    $table['version'] = '1.0.0';
    $table['datastreams'] = array(
	    array(
		'alias'=> $row[0] . '-' . $hotfix,
		'location'=> '',
		'pollutant'=> $row[2],
		'id'=> $row[1],
		'datapoints' => $value_array
		)
	    );
	$jsondata = json_encode($table, JSON_PRETTY_PRINT);
	var_dump($jsondata);
		}}}
/* Waiting for new code
    //http request with database query
    $http_res = $dbconnect->query('SELECT * FROM nanodb');
    while ($httpreq = $http_res->fetch_array(MYSQLI_BOTH)) {
	$Auth = $httpreq['location'];
	$table['datastreams'][0]['location'] = $httpreq['location'];
	}
	$url = $httpreq['addr'];
	if ($httpreq['port'] != NULL)
	    $url = $url . ':' . $httpreq['port'];
	if ($httpreq['path'][0] != '/')
	    $url = $url . '/' . $httpreq['path'];
	else
	    $url = $url . $httpreq['path'];
	fwrite($logfile, $url . "\t");
	$ch = curl_init($pieces[4]);
	$login = $httpreq['login'];
	$pass = $httpreq['password'];
	//		var_dump($url);
	$jsondata = json_encode($table, JSON_PRETTY_PRINT);
	//		echo $row[0] . '-' . $hotfix;
	//		echo "\n";
	#
	# Set the HTTP POST REQUEST with CURL
	#
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		    'Content-Type: application/json',
		    'Token:'. ' ' . $Auth,
		    ));
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_USERPWD, "$login:$pass");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLINFO_HEADER_OUT, true);//debug
fclose($backupfile);
	$res = curl_exec($ch);
	echo $jsondata . "\n";
	fwrite($logfile, $res . "\n");
	$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	if (curl_errno($ch))
	{
	    echo 'error:'. curl_error($ch);
	}
	curl_close($ch);
    }
}
fclose($logfile);
mysqli_close($dbconnect);
*/
fclose($backupfile);
?>
