<?php


$json = file_get_contents('/home/pi/enocean-gateway/send-backup-script/missedata.json');
$jsondecode = json_decode($json, true);

exec("ping -q -w 1 -c 1 `ip r | grep default | cut -d ' ' -f 3` > /dev/null && echo 'ok' || echo 'error'",$disp,$ret);
$date = date("Y-m-d H:i:s");
var_dump($ret);
var_dump($disp);

if ($disp[0] == "ok"){
    foreach($jsondecode AS $key => $value){
	if ($key == 'isalive'){
	    $jsondecode[$key] = $date;}
    }
}
else{
    foreach($jsondecode AS $key => $value){
	if ($key == 'isdead'){
	    $jsondecode[$key] = $date;}
    }
}
$newjson = json_encode($jsondecode, JSON_PRETTY_PRINT);
var_dump($newjson);
file_put_contents('/home/pi/enocean-gateway/send-backup-script/missedata.json', $newjson);
?>
