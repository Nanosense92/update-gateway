<?php
/*
 * FILE : misc.php
 *
 * DESCRIPTION : contains all the useful functions for the different scripts
 *
 */

// Rename the pollutant name in order to not exceed 5 characters
function setpollutant($pollutant){
    if ($pollutant == 'PM2.5')
        return 'PM2_5';
    if (strpos($pollutant, 'Temp') !== false)
        return 'TMP';
    if (strpos($pollutant, 'Hum') !== false)
        return 'HUM';
    if (strpos($pollutant, 'Total') !== false)
        return 'VOC';
    else
        return $pollutant;
}

// Translate the pollutant name to its real command name (in Jeedom)
function r_setpollutant($pollutant){
    if ($pollutant == 'PM2_5')
        return 'PM2.5';
    if ($pollutant == 'TMP')
        return 'Température';
    if ($pollutant == 'HUM')
        return 'Humidité';
    if ($pollutant == 'VOC')
        return 'Total';
    else
        return $pollutant;
}

?>
