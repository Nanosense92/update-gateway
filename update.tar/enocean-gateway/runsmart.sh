#!/bin/sh

/home/pi/enocean-gateway/SmartIAQ & /home/pi/enocean-gateway/gat-to-log
pkill -9 -f SmartIAQ
