<?php
$json = file_get_contents('/home/pi/Nano-Setting.json');
$jsondecode = json_decode($json, true);
$offset = 0;
foreach($jsondecode AS $key => $value){
    if ($key == 'timezone'){
        $offset = (int)$value;}
}
if ($offset > 0){
    $offset = ($offset - 1) . ':55:00';
}
else{
    $offset = ($offset) . ':-05:00';
}

/*
 * database identification
 */
$hostname = 'localhost';
$username = 'jeedom';
$password = '85522aa27894d77';
$db = 'jeedom';

$dbconnect = mysqli_connect($hostname, $username, $password, $db);
$logfile = fopen('postphysio.log', 'w');
if ($dbconnect->connect_errno){
    printf('connection failed');
    exit;
}

/*
 * Formating the data to send a correct JSON file
 */
$table = array();
$dist_loc_query = $dbconnect->query('SELECT DISTINCT location FROM impact');
while ($row_loc = $dist_loc_query->fetch_array(MYSQLI_BOTH)){
    for ($i = 3; $i < 8; $i++){
        $value_array = array();
        $value_query = $dbconnect->query("SELECT * FROM impact WHERE location = '" . $row_loc[0] . "' " .
            "AND datetime > ADDTIME(now(), '" . $offset . "')");

        if ($value_query->num_rows != 0){
            fwrite($logfile, date('Y-m-d H:i:s') . "\t");
            fwrite($logfile, $row_loc[0]);
        }
        while ($row_val = $value_query->fetch_array(MYSQLI_BOTH)){
            $value_array[] = array(
                "at" => date("Y-m-d\TH:i:s\Z", strtotime($row_val[0] . '-2 hours')),
                "value" => $row_val[$i]
            );
        }

        $table['version'] = "1.0.0";
        $effect_name_query = $dbconnect->query("SELECT column_name FROM information_schema.columns " .
            "WHERE table_schema = 'jeedom' AND table_name = 'impact' limit 1 offset " . $i);
        $effect_name_row = $effect_name_query->fetch_array(MYSQLI_BOTH);

        $table['datastreams'] = array(
            array(
                'alias' => $row_loc[0] . '-' . $effect_name_row[0],
                'location' => $row_loc[0],
                'pollutant' => $effect_name_row[0],
                'datapoints' => $value_array
            )
        );
        if ($value_query->num_rows != 0)
            fwrite($logfile, '-' . $effect_name_row[0] . "\n");

        //http request with database query
        $http_query = $dbconnect->query('SELECT * FROM nanodb');
        while ($http_row = $http_query->fetch_array(MYSQLI_BOTH)){

            $auth = $http_row['location'];
            $url = $http_row['addr'] . ':' . $http_row['port'] . '/' . $http_row['path'];
            $login = $http_row['login'];
            $pass = $http_row['password'];
            var_dump($url);

            if ($value_query->num_rows != 0)
                fwrite($logfile, $url . "\t");

            $ch = curl_init($url);
            $jsondata = json_encode($table, JSON_PRETTY_PRINT);
            echo $row_loc[0] . '-' . $effect_name_row[0] . "\n";

            /*
             *  Set the HTTP Post request with CURL
             */
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Token: ' . $auth,
            )); 
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_USERPWD, "$login:$pass");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true); //debug
            $curl_res = curl_exec($ch);

            //debug
            $headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT );
            var_dump(curl_getinfo($ch, CURLINFO_HTTP_CODE));
            var_dump($headerSent);
            echo $jsondata . "\n";
            //debug

            if ($value_query->num_rows != 0)
                fwrite($logfile, $curl_res . "\n");
            var_dump($curl_res);

            if (curl_errno($ch)){
                echo 'curl error: '. curl_error($ch);
            }
            curl_close($ch);
        }
    }
}
fclose($logfile);
mysqli_close($dbconnect);
?>
