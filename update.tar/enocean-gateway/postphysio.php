<?php
$json = file_get_contents('/home/pi/Nano-Setting.json');
$jsondecode = json_decode($json, true);
$offset = 0;
$timezone_offset = 0;
$send_data_interval = 0;
$average_mode = 0;
foreach($jsondecode AS $key => $value){
    if ($key == 'timezone'){
        $timezone_offset = (int)$value;
    }
    else if ($key == 'send-data-interval'){
        $send_data_interval = (int)$value;
    }
}
if ($timezone_offset > 0){
    $offset = ($timezone_offset - 1) . ':' . (60 - $send_data_interval) . '00';
}
else{
    $offset = '-' . ($timezone_offset) . ':' . (60 - $send_data_interval) . ':00';
}

/*
 * Database identification
 */
$hostname = 'localhost';
$username = 'jeedom';
$password = '85522aa27894d77';
$db = 'jeedom';

// Connect to the database
$dbconnect = mysqli_connect($hostname, $username, $password, $db);
if ($dbconnect->connect_errno){
    printf('connection failed');
    exit;
}

$logfile = fopen('/home/pi/postphysio.log', 'w');

/*
 * Query on the jeedom database to get all the distinct location from the impact
 * table
 */
$dist_loc_query = 'SELECT DISTINCT location FROM impact';
$dist_loc_cmd_query = $dbconnect->query($dist_loc_query);

/*
 * Formating the data to send a correct JSON file
 */
$table = array();
while ($dist_loc_row = $dist_loc_cmd_query->fetch_array(MYSQLI_BOTH)){
    for ($i = 3; $i < 8; $i++){
        $value_array = array();

        /*
         * Query to get all the values of one physiological impact within the last
         * "$send_data_interval" minutes
         */
        $val_query = "SELECT * FROM impact WHERE location = '$dist_loc_row[0]' "
            . "AND datetime > ADDTIME(now(), '" . $offset . "')";
        $val_cmd_query = $dbconnect->query($val_query);

        if ($val_cmd_query->num_rows != 0){
            fwrite($logfile, date('Y-m-d H:i:s') . "\t");
            fwrite($logfile, $dist_loc_row[0]);
        }

        while ($val_row = $val_cmd_query->fetch_array(MYSQLI_BOTH)){
            // Build the main array that will contain all the values for one physio. impact
            $value_array[] = array(
                "at" => date("Y-m-d\TH:i:s\Z",
                    strtotime($val_row[0] . '-' . $timezone_offset . 'hours')),
                "value" => $val_row[$i]
            );
            //var_dump($value_array);
        }

        /*
         * Query to get all the physio. effects name
         */
        $effect_name_query = "SELECT column_name FROM information_schema.columns "
            . "WHERE table_schema = 'jeedom' AND table_name = 'impact' limit 1 offset "
            . $i;
        $effect_name_cmd_query = $dbconnect->query($effect_name_query);
        $effect_name_row = $effect_name_cmd_query->fetch_array(MYSQLI_BOTH);

        // Build the header of the JSON
        $table['version'] = "1.0.0";
        $table['datastreams'] = array(
            array(
                'alias' => $dist_loc_row[0] . '-' . $effect_name_row[0],
                'location' => $dist_loc_row[0],
                'pollutant' => $effect_name_row[0],
                'id' => '',
                'datapoints' => $value_array
            )
        );
        if ($val_cmd_query->num_rows != 0)
            fwrite($logfile, '-' . $effect_name_row[0] . "\n");

        // HTTP request with database query
        $http_query = $dbconnect->query('SELECT * FROM nanodb');
        while ($http_row = $http_query->fetch_array(MYSQLI_BOTH)){

            if ($http_row['addr'] == 'http://192.168.0.34')
                continue;
            $auth = $http_row['location'];
            $url = $http_row['addr'] . ':' . $http_row['port'] . '/' . $http_row['path'];
            $login = $http_row['login'];
            $pass = $http_row['password'];

            if ($val_cmd_query->num_rows != 0)
                fwrite($logfile, $url . "\t");

            $ch = curl_init($url);
            $jsondata = json_encode($table, JSON_PRETTY_PRINT);

            /*
             *  Set the HTTP Post request with CURL
             */
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Token: ' . $auth,
            )); 
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_USERPWD, "$login:$pass");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsondata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true); //debug
            $curl_res = curl_exec($ch);

            /* DEBUG */
            /*
            $headerSent = curl_getinfo($ch, CURLINFO_HEADER_OUT );
            var_dump(curl_getinfo($ch, CURLINFO_HTTP_CODE));
            var_dump($headerSent);
            echo $jsondata . "\n";
            */
            /* DEBUG */

            if ($val_cmd_query->num_rows != 0)
                fwrite($logfile, $curl_res . "\n");

            if (curl_errno($ch)){
                echo 'CURL error: '. curl_error($ch);
            }
            curl_close($ch);
        }
    }
}
fclose($logfile);
mysqli_close($dbconnect);
?>
