<?php
/*
 * FILE : postphysio.php
 */

include 'getsettings.php';
include 'httprequest.php';

$logfile = fopen('/home/pi/postphysio.log', 'a');
$errorlogfile = fopen('/home/pi/postphysio_error.log', 'a');

/*
 * Query on the jeedom database to get all the distinct location from the impact
 * table
 */
$dist_loc_query = 'SELECT DISTINCT location FROM impact';
$dist_loc_cmd_query = $dbconnect->query($dist_loc_query);

/*
 * Formating the data to send a correct JSON file
 */
$table = array();
while ($dist_loc_row = $dist_loc_cmd_query->fetch_array(MYSQLI_BOTH)){
    for ($i = 3; $i < 8; $i++){
        $value_array = array();

        /*
         * Query to get all the values of one physiological impact within the last
         * "$send_data_interval" minutes
         */
        $val_query = "SELECT * FROM impact WHERE location = '$dist_loc_row[0]' "
            . "AND datetime > ADDTIME(now(), '" . $offset . "')";
        $val_cmd_query = $dbconnect->query($val_query);

        fwrite($logfile, date('Y-m-d H:i:s') . "\t");
        fwrite($logfile, $dist_loc_row[0]);

        while ($val_row = $val_cmd_query->fetch_array(MYSQLI_BOTH)){
            // Build the main array that will contain all the values for one physio. impact
            $value_array[] = array(
                "at" => date("Y-m-d\TH:i:s\Z",
                    strtotime($val_row[0] . '-' . $timezone_offset . 'hours')),
                "value" => $val_row[$i]
            );
            //var_dump($value_array);
        }

        /*
         * Query to get all the physio. effects name
         */
        $effect_name_query = "SELECT column_name FROM information_schema.columns "
            . "WHERE table_schema = 'jeedom' AND table_name = 'impact' limit 1 offset "
            . $i;
        $effect_name_cmd_query = $dbconnect->query($effect_name_query);
        $effect_name_row = $effect_name_cmd_query->fetch_array(MYSQLI_BOTH);

        // Build the header of the JSON
        $table['version'] = "1.0.0";
        $table['datastreams'] = array(
            array(
                'alias' => $dist_loc_row[0] . '-' . $effect_name_row[0],
                'location' => $dist_loc_row[0],
                'pollutant' => $effect_name_row[0],
                'id' => '',
                'datapoints' => $value_array
            )
        );
        fwrite($logfile, '-' . $effect_name_row[0] . "\n");

        // HTTP request with database query
        http_request($dbconnect, $logfile, $table, $dist_loc_row[0],
            $effect_name_row[0], $errorlogfile);
    }
}
fclose($logfile);
fclose($errorlogfile);
mysqli_close($dbconnect);
?>
