<?php
    require_once "/var/www/html/core/config/common.config.php";
 
    $jeedom_db_passwd = $GLOBALS['CONFIG']['db']['password'];

    //echo $jeedom_db_passwd . "\n";    
?>
