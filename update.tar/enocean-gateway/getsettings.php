<?php
/*
 * Settings file paramaters
 */
$json = file_get_contents('/home/pi/Nano-Setting.json');
$jsondecode = json_decode($json, true);
foreach($jsondecode AS $key => $value){
    switch($key){
        case 'timezone':
            $timezone_offset = (int)$value;
            break;
        case 'send-data-interval':
            $send_data_interval = (int)$value;
            break;
        case 'average-mode':
            $average_mode = (int)$value;
            break;
    }
}

if ($timezone_offset > 0){
    $offset = ($timezone_offset - 1) . ':' . (60 - $send_data_interval) . ':00';
}
else{
    $offset = '-' . ($timezone_offset) . ':' . (60 - $send_data_interval) . ':00';
}

/*
 * Database identification
 */
$hostname = 'localhost';
$username = 'jeedom';
$password = '85522aa27894d77';
$db = 'jeedom';

// Connect to the database
$dbconnect = mysqli_connect($hostname, $username, $password, $db);
if ($dbconnect->connect_errno){
    printf("Connection to '$db' database failed with this configuration");
    exit;
}
?>
