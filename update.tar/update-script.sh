#!/bin/sh

LOG='/home/pi/update.log'
TRASH='/dev/null'

sudo echo "$(date): starting update script" >> $LOG;

UPVERS=$(cat update-gateway/version-update.txt)
CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

sudo echo "update version: " $UPVERS
sudo echo "current version: " $CURVERS

restore_original_backup () {
    sudo rm -rf /home/pi/backup/ 2>> $TRASH;
    sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> $TRASH;
}

restore_new_backup () {
    sudo mv -f /home/pi/backup/Nano-Setting.json /home/pi/ 2>> $TRASH;
    sudo mv -f /home/pi/backup/crontabs/pi /var/spool/cron/crontabs/ 2>> $TRASH;
    sudo mv -f /home/pi/backup/enocean-gateway/ /home/pi/ 2>> $TRASH;
    sudo mv -f /home/pi/backup/nanosense/ /var/www/html/ 2>> $TRASH;
}

if [ $UPVERS -gt $CURVERS ]
then
    PHP_UPDATE_PID=$(ps aux | grep -v "grep" | grep "update.php" | cut -d ' ' -f 8)
    sudo kill -STOP $PHP_UPDATE_PID
    sudo echo "$(date): creating a backup of the actual firmware..." >> $LOG;

    # save the current backup (if there is one) in the case a problem occurs while creating a new one
    sudo mv -f /home/pi/backup/ /home/pi/backup_copy/ 2>> $TRASH;

    # create a new backup folder to save all the current firmware
    ERROR=$(sudo mkdir /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$? 
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error: $ERROR" >> $LOG;
        exit $RET
    fi

    # backup all the current firmware
    ERROR=$(sudo cp -rf /home/pi/enocean-gateway/ /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current data push scripts" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        restore_original_backup
        exit $RET
    fi
    
    ERROR=$(sudo cp -rf /var/www/html/nanosense/ /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current web-interface" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        restore_original_backup
        exit $RET
    fi
    
    ERROR=$(sudo cp -f /home/pi/Nano-Setting.json /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current firmware configuration" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        restore_original_backup
        exit $RET
    fi
    
    #ERROR=$(sudo cp -f /home/pi/update-gateway/backup-script.sh /home/pi/backup/ 2>&1 1>>$TRASH)
    #RET=$?
    #if [ $RET -gt 0 ]
    #then
    #    sudo echo "$(date): error: no backup script found in the update" >> $LOG;
    #    sudo echo "$(date): error: $ERROR" >> $LOG;
    #    restore_original_backup
    #    exit $RET
    #fi
    
    sudo mkdir /home/pi/backup/crontabs/ 2>> $TRASH;
    ERROR=$(sudo cp -f /var/spool/cron/crontabs/pi /home/pi/backup/crontabs/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current crontab file" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        restore_original_backup
        exit $RET
    fi
    sudo echo "$(date): backup successfully created" >> $LOG; 

    # update all the firmware
    sudo echo "$(date): updating from version" $CURVERS "to version" $UPVERS >> $LOG; 

    sudo echo "$(date): updating data push scripts and routines" >> $LOG;
    ERROR=$(sudo cp -rf update-gateway/enocean-gateway/ /home/pi/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while updating data push scripts" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        # error: need to restore the backup of the system
        restore_new_backup
        restore_original_backup
        exit $RET
    fi

    sudo echo "$(date): updating web-interface" >> $LOG;
    ERROR=$(sudo cp -rf update-gateway/nanosense/ /var/www/html/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while updating web-interface" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        # error: need to restore the backup of the system
        restore_new_backup
        restore_original_backup
        exit $RET
    fi
    
    sudo echo "$(date): updating json configuration file" >> $LOG;
    ERROR=$(sudo cp -f update-gateway/Nano-Setting.json /home/pi/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while updating json configuration file" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        # error: need to restore the backup of the system
        restore_new_backup
        restore_original_backup
        exit $RET
    fi
    # manipulation on the Nano-Setting file to make it have the right properties
    sudo dos2unix /home/pi/Nano-Setting.json 2>> $TRASH;
    sudo chown pi:pi /home/pi/Nano-Setting.json 2>> $TRASH;
    sudo chmod 777 /home/pi/Nano-Setting.json 2>> $TRASH;

    sudo echo "$(date): updating crontab file" >> $LOG;
    ERROR=$(sudo cp -f update-gateway/crontabs/pi /var/spool/cron/crontabs/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while updating crontab file" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        # error: need to restore the backup of the system
        restore_new_backup
        restore_original_backup
        exit $RET
    fi
    # manipulation on the crontab pi file to make it have the right properties
    sudo dos2unix /var/spool/cron/crontabs/pi 2>> $TRASH;
    sudo chown pi:crontab /var/spool/cron/crontabs/pi 2>> $TRASH;
    sudo chmod 600 /var/spool/cron/crontabs/pi 2>> $TRASH;
    ERROR=$(sudo crontab -l -u pi | crontab -u pi - 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        sudo echo "$(date): error while reloading the crontab file" >> $LOG;
        sudo echo "$(date): error: $ERROR" >> $LOG;
        # error: need to restore the backup of the system
        restore_new_backup
        restore_original_backup
        exit $RET
    fi

    # remove the backup copy
    sudo rm -rf /home/pi/backup_copy/ 2>> $TRASH;
    
    sudo kill -CONT $PHP_UPDATE_PID
else
    sudo echo "$(date): already to the newest version:" $UPVERS >> $LOG;
fi
