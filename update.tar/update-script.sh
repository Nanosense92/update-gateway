#!/bin/sh
sudo echo "$(date): starting update script" >> /home/pi/update.log;

UPVERS=$(cat update-gateway/version-update.txt)
CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

sudo echo "update version: " $UPVERS
sudo echo "current version: " $CURVERS

if [ $UPVERS -gt $CURVERS ]
then
    sudo echo "$(date): creating a backup of the actual firmware version and configuration"
    sudo echo "$(date): creating a backup of the actual firmware version and configuration" >> /home/pi/update.log
    sudo mkdir /home/pi/backup/
    sudo mv -f /home/pi/enocean-gateway/ /home/pi/backup/
    sudo mv -f /var/www/html/nanosense/ /home/pi/backup/
    sudo mv -f /home/pi/Nano-Setting.json /home/pi/backup/
    sudo mv -f /home/pi/update-gateway/backup-script.sh /home/pi/backup/
    
    sudo mkdir /home/pi/backup/crontabs/
    sudo mv -f /var/spool/cron/crontabs/pi /home/pi/backup/crontabs/

    sudo echo "$(date): updating from version" $CURVERS "to version" $UPVERS

    sudo echo "$(date): updating data push scripts and routines" >> /home/pi/update.log;
    sudo cp -rf update-gateway/enocean-gateway/ /home/pi/

    sudo echo "$(date): updating web-interface" >> /home/pi/update.log;
    sudo cp -rf update-gateway/nanosense/ /var/www/html/
    
    sudo echo "$(date): updating json configuration file" >> /home/pi/update.log;
    sudo cp -rf update-gateway/Nano-Setting.json /home/pi/
    sudo dos2unix /home/pi/Nano-Setting.json
    sudo chown pi:pi /home/pi/Nano-Setting.json
    sudo chmod 777 /home/pi/Nano-Setting.json

    sudo echo "$(date): updating crontab" >> /home/pi/update.log;

    sudo cp -rf update-gateway/crontabs/pi /var/spool/cron/crontabs/
    sudo dos2unix update-gateway/crontabs/pi
    sudo chown pi:crontab /var/spool/cron/crontabs/pi
    sudo chmod 600 /var/spool/cron/crontabs/pi
    sudo crontab -l -u pi | crontab -u pi -

else
    sudo echo "$(date): already to the newest version:" $UPVERS
    sudo echo "$(date): already to the newest version:" $UPVERS >> /home/pi/update.log;
fi
