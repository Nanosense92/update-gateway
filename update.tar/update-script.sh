#!/bin/sh

UPVERS=$(cat version-update.txt)
CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

echo "update version: " $UPVERS
echo "current version " $CURVERS

if [ $UPVERS -gt $CURVERS ]
then
	echo "updating"
	echo "updating the gateway" >> /home/pi/update_log.log;

	sudo cp -rf /home/pi/enocean-gateway /home/pi/backup 
	sudo cp -rf update-gateway/enocean-gateway /home/pi

	echo "updating script and routine" >> /home/pi/update_log.log;

	sudo cp -rf /var/www/html/nanosense /home/pi/backup
	sudo cp -rf update-gateway/nanosense /var/www/html

	echo "updating web-interface" >> /home/pi/update_log.log;

	sudo echo $(cat update-gateway/version-update.txt) > /home/pi/nano-version.txt
else
	echo "already to newest"
	echo "Already to the Newest version" >> /home/pi/update_log.log;

fi
