#!/bin/sh

UPVERS=$(cat update-gateway/version-update.txt)
CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

echo "update version: " $UPVERS
echo "current version: " $CURVERS

if [ $UPVERS -gt $CURVERS ]
then
    echo "updating"
    echo "updating the gateway" >> /home/pi/update_log.log;
    sudo mkdir /home/pi/backup/

    sudo mv -f /home/pi/enocean-gateway/ /home/pi/backup/
    sudo cp -rf update-gateway/enocean-gateway/ /home/pi/

    echo "updating script and routine" >> /home/pi/update_log.log;

    sudo mv -f /var/www/html/nanosense/ /home/pi/backup/
    sudo cp -rf update-gateway/nanosense/ /var/www/html/

    echo "updating web-interface" >> /home/pi/update_log.log;
    sudo mv -f /home/pi/Nano-Setting.json /home/pi/backup/
    sudo cp -rf update-gateway/Nano-Setting.json /home/pi/

    echo "updating crontab" >> /home/pi/update_log.log;
    sudo mkdir /home/pi/backup/crontabs/

    sudo mv -f /var/spool/cron/crontabs/pi /home/pi/backup/crontabs/
    sudo cp -rf update-gateway/crontabs/pi /var/spool/cron/crontabs/
    sudo dos2unix update-gateway/crontabs/pi
    sudo chown pi:crontab /var/spool/cron/crontabs/pi
    sudo chmod 600 /var/spool/cron/crontabs/pi
    sudo crontab -l -u pi | crontab -u pi -

else
    echo "already to the newest version"
    echo "already to the newest version" >> /home/pi/update_log.log;

fi
