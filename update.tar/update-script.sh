#!/bin/sh
sudo echo "$(date): starting update script" >> /home/pi/update.log;

UPVERS=$(cat update-gateway/version-update.txt)
CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

sudo echo "update version: " $UPVERS
sudo echo "current version: " $CURVERS

if [ $UPVERS -gt $CURVERS ]
then
    sudo echo "$(date): creating a backup of the actual firmware" >> /home/pi/update.log;

    # save the current backup (if there is one) in the case a problem occurs while creating a new one
    sudo mv -f /home/pi/backup/ /home/pi/backup_copy/ 2>> /dev/null

    # create a new backup folder to save all the current firmware
    sudo mkdir /home/pi/backup/ 2>> /dev/null

    # backup all the current firmware
    sudo mv -f /home/pi/enocean-gateway/ /home/pi/backup/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current data push scripts" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    
    sudo mv -f /var/www/html/nanosense/ /home/pi/backup/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current web-interface" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    
    sudo mv -f /home/pi/Nano-Setting.json /home/pi/backup/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current firmware configuration" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    
    sudo mv -f /home/pi/update-gateway/backup-script.sh /home/pi/backup/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error: no backup script found in the update" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    
    sudo mkdir /home/pi/backup/crontabs/ 2>> /dev/null
    sudo mv -f /var/spool/cron/crontabs/pi /home/pi/backup/crontabs/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while creating a backup of the current crontab file" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi

    # update all the firmware
    sudo echo "$(date): updating from version" $CURVERS "to version" $UPVERS >> /home/pi/update.log;

    sudo echo "$(date): updating data push scripts and routines" >> /home/pi/update.log;
    sudo cp -rf update-gateway/enocean-gateway/ /home/pi/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while updating data push scripts" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi

    sudo echo "$(date): updating web-interface" >> /home/pi/update.log;
    sudo cp -rf update-gateway/nanosense/ /var/www/html/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while updating web-interface" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    
    sudo echo "$(date): updating json configuration file" >> /home/pi/update.log;
    sudo cp -rf update-gateway/Nano-Setting.json /home/pi/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while updating json configuration file" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    sudo dos2unix /home/pi/Nano-Setting.json 2>> /dev/null
    sudo chown pi:pi /home/pi/Nano-Setting.json 2>> /dev/null
    sudo chmod 777 /home/pi/Nano-Setting.json 2>> /dev/null

    sudo echo "$(date): updating crontab file" >> /home/pi/update.log;
    sudo cp -rf update-gateway/crontabs/pi /var/spool/cron/crontabs/ 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while updating crontab file" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi
    sudo dos2unix update-gateway/crontabs/pi 2>> /dev/null
    sudo chown pi:crontab /var/spool/cron/crontabs/pi 2>> /dev/null
    sudo chmod 600 /var/spool/cron/crontabs/pi 2>> /dev/null
    sudo crontab -l -u pi | crontab -u pi - 2>> /dev/null
    if [ $? -gt 0 ]
    then
        sudo echo "$(date): error while reloading the crontab file" >> /home/pi/update.log;
        sudo rm -rf /home/pi/backup/ 2>> /dev/null
        sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> /dev/null
        exit 1
    fi

    # remove the backup copy
    sudo rm -rf /home/pi/backup_copy/ 2>> /dev/null

else
    sudo echo "$(date): already to the newest version:" $UPVERS >> /home/pi/update.log;
fi
