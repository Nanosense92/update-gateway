#!/bin/sh

LOG='/var/log/update.log'
TRASH='/dev/null'

restore_original_backup () {
    sudo rm -rf /home/pi/backup/ 2>> $TRASH;
    sudo mv -f /home/pi/backup_copy/ /home/pi/backup/ 2>> $TRASH;
}

restore_new_backup () {
    sudo mv -f /home/pi/backup/Nano-Setting.json /home/pi/ 2>> $TRASH;
    sudo mv -f /home/pi/backup/crontabs/pi /var/spool/cron/crontabs/ 2>> $TRASH;
    sudo mv -f /home/pi/backup/enocean-gateway/ /home/pi/ 2>> $TRASH;
    sudo mv -f /home/pi/backup/nanosense/ /var/www/html/ 2>> $TRASH;
}

# $1 is the type of message (INFO, DEBUG, WARN, ERROR)
# $2 is the message to write in the log file
write_to_log () {
    sudo echo "$(date): $1: $2" >> $LOG;
}

# idem as the first one except that it exits with $3
write_to_log_and_exit () {
    write_to_log "$1" "$2";
    exit $3;
}

# idem as the second one except that it restores the initial backup before exiting
write_to_log_restore_and_exit () {
    write_to_log "$1" "$2";
    restore_original_backup
    exit $3;
}

# idem as the third one except that it restores the new backup and the initial backup before exiting
write_to_log_restore2_and_exit () {
    write_to_log "$1" "$2";
    restore_new_backup
    restore_original_backup
    exit $3;
}

write_to_log "INFO" "starting update script"

UPVERS=$(cat update-gateway/version-update.txt)
CURVERS=$(cat /home/pi/Nano-Setting.json | grep "version" | cut -d "\"" -f4)

sudo echo "update version: " $UPVERS
sudo echo "current version: " $CURVERS

if [ $UPVERS -gt $CURVERS ]
then
    write_to_log "INFO" "creating a backup of the actual firmware..."

    # save the current backup (if there is one) in the case a problem occurs while creating a new one
    ERROR=$(sudo mv -f /home/pi/backup/ /home/pi/backup_copy/ 2>> $TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "WARN" "$ERROR"
    fi

    # create a new backup folder to save all the current firmware
    ERROR=$(sudo mkdir /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$? 
    if [ $RET -gt 0 ]
    then
        write_to_log_and_exit "ERROR" "$ERROR" "$RET"
    fi

    write_to_log "INFO" "backup directory successfully created"

    # BACKUP OF ALL THE CURRENT FIRMWARE
    ERROR=$(sudo cp -rf /home/pi/enocean-gateway/ /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while creating a backup of the current data push scripts"
        write_to_log_restore_and_exit "ERROR" "$ERROR" "$RET"
    fi

    write_to_log "INFO" "data push scripts successfully backed up"

    ERROR=$(sudo cp -rf /var/www/html/nanosense/ /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while creating a backup of the current web-interface"
        write_to_log_restore_and_exit "ERROR" "$ERROR" "$RET"
    fi
    
    write_to_log "INFO" "web-interface successfully backed up"
    
    ERROR=$(sudo cp -f /home/pi/Nano-Setting.json /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while creating a backup of the current configuration"
        write_to_log_restore_and_exit "ERROR" "$ERROR" "$RET"
    fi
    
    write_to_log "INFO" "firmware configuration successfully backed up"

    sudo mkdir /home/pi/backup/crontabs/ 2>> $TRASH;
    ERROR=$(sudo cp -f /var/spool/cron/crontabs/pi /home/pi/backup/crontabs/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while creating a backup of the current crontab file"
        write_to_log_restore_and_exit "ERROR" "$ERROR" "$RET"
    fi
    
    write_to_log "INFO" "backup successfully created"
    
    # --------------------------------------------------------------------------

    # UPDATE OF ALL THE FIRMWARE
    write_to_log "INFO" "updating from version $CURVERS to version $UPVERS..."
    
    ERROR=$(sudo cp -f update-gateway/backup-script.sh /home/pi/backup/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "no backup script found in the update"
        write_to_log_restore_and_exit "ERROR" "$ERROR" "$RET"
    fi
    
    write_to_log "INFO" "updating data push scripts and routines..."
    
    ERROR=$(sudo cp -rf update-gateway/enocean-gateway/ /home/pi/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while updating the data push scripts"
        write_to_log_restore2_and_exit "ERROR" "$ERROR" "$RET"
    fi

    write_to_log "INFO" "data push scripts and routines successfully updated"
    
    write_to_log "INFO" "updating web-interface..."
    
    ERROR=$(sudo cp -rf update-gateway/nanosense/ /var/www/html/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while updating the web-interface"
        write_to_log_restore2_and_exit "ERROR" "$ERROR" "$RET"
    fi
    
    write_to_log "INFO" "web-interface successfully updated"
    
    write_to_log "INFO" "updating json configuration file..."
    
    ERROR=$(sudo cp -f update-gateway/Nano-Setting.json /home/pi/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while updating the json configuration file"
        write_to_log_restore2_and_exit "ERROR" "$ERROR" "$RET"
    fi
    # manipulation on the Nano-Setting file to have the right properties
    sudo dos2unix /home/pi/Nano-Setting.json 2>> $TRASH;
    sudo chown pi:pi /home/pi/Nano-Setting.json 2>> $TRASH;
    sudo chmod 777 /home/pi/Nano-Setting.json 2>> $TRASH;

    write_to_log "INFO" "json configuration file sucessfully updated"
    
    write_to_log "INFO" "updating crontab file..."
    
    ERROR=$(sudo cp -f update-gateway/crontabs/pi /var/spool/cron/crontabs/ 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while updating the crontab file"
        write_to_log_restore2_and_exit "ERROR" "$ERROR" "$RET"
    fi
    # manipulation on the crontab pi file to have the right properties
    sudo dos2unix /var/spool/cron/crontabs/pi 2>> $TRASH;
    sudo chown pi:crontab /var/spool/cron/crontabs/pi 2>> $TRASH;
    sudo chmod 600 /var/spool/cron/crontabs/pi 2>> $TRASH;
    ERROR=$(sudo crontab -l -u pi | crontab -u pi - 2>&1 1>>$TRASH)
    RET=$?
    if [ $RET -gt 0 ]
    then
        write_to_log "ERROR" "error while reloading the crontab file"
        write_to_log_restore2_and_exit "ERROR" "$ERROR" "$RET"
    fi

    write_to_log "INFO" "crontab file successfully updated"
    
    # remove the backup copy
    sudo rm -rf /home/pi/backup_copy/ 2>> $TRASH;

    # launch optimize script
    sudo sh /home/pi/update-gateway/optimize-sd-card.sh

    # launch script that allow people accessing the web interface to download the .sql dump file
    sudo sh /home/pi/update-gateway/authorize-file-access.sh
   
    # move log files
    sudo sh /home/pi/update-gateway/mv_log_files.sh

    # enable RSSI historization
    sudo php /home/pi/update-gateway/enable_rssi_dBm_historization_jeedom.php

    # disable value smoothing for all Jeedom commands
    sudo php /home/pi/update-gateway/change_historize_round_cmd_jeedom.php

    # configure remote access + send a mail containing all the useful infos of the GW
    /home/pi/update-gateway/config_reverse_ssh_remote_access.sh
else
    write_to_log "INFO" "already to the newest version: $UPVERS"
fi
