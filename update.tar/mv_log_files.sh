#!/bin/sh

# move log files to /var/log
sudo mv -f /home/pi/postdata.log /home/pi/postdata_error.log /var/log/
sudo mv -f /home/pi/postphysio.log /home/pi/postphysio_error.log /var/log/
sudo mv -f /home/pi/update.log /var/log/
