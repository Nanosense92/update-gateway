#!/bin/sh

# move log files to /var/log
sudo mv -f /home/pi/postdata.log /home/pi/postdata_error.log /var/log/
sudo mv -f /home/pi/postphysio.log /home/pi/postphysio_error.log /var/log/
sudo mv -f /home/pi/update.log /var/log/
sudo mv -f /home/pi/SmartIAQ.log /var/log/

# change owner to pi
sudo chown pi:pi /var/log/postdata.log /var/log/postdata_error.log
sudo chown pi:pi /var/log/postphysio.log /var/log/postphysio_error.log
sudo chown pi:pi /var/log/update.log
sudo chown pi:pi /var/log/SmartIAQ.log
